var searchData=
[
  ['flash_5fpb_5fapi',['Flash_pb_api',['../group__flash__pb__api.html',1,'']]],
  ['flashpbget',['FlashPBGet',['../group__flash__pb__api.html#gab243c2b0f158e0a3c8c89d25d923df5f',1,'FlashPBGet(void):&#160;flash_pb.c'],['../group__flash__pb__api.html#gab243c2b0f158e0a3c8c89d25d923df5f',1,'FlashPBGet(void):&#160;flash_pb.c']]],
  ['flashpbinit',['FlashPBInit',['../group__flash__pb__api.html#gae1026232dae81709cbe4f7b956749942',1,'FlashPBInit(uint32_t ui32Start, uint32_t ui32End, uint32_t ui32Size):&#160;flash_pb.c'],['../group__flash__pb__api.html#gae1026232dae81709cbe4f7b956749942',1,'FlashPBInit(uint32_t ui32Start, uint32_t ui32End, uint32_t ui32Size):&#160;flash_pb.c']]],
  ['flashpbsave',['FlashPBSave',['../group__flash__pb__api.html#ga0f202e339edf1758a8b484afa19fb074',1,'FlashPBSave(uint8_t *pui8Buffer):&#160;flash_pb.c'],['../group__flash__pb__api.html#ga0f202e339edf1758a8b484afa19fb074',1,'FlashPBSave(uint8_t *pui8Buffer):&#160;flash_pb.c']]],
  ['fs_5fclose',['fs_close',['../group__fswrapper__api.html#ga4d157f02006ca8d1aed082b566378898',1,'fs_close(struct fs_file *phFile):&#160;fswrapper.c'],['../group__fswrapper__api.html#ga4d157f02006ca8d1aed082b566378898',1,'fs_close(struct fs_file *file):&#160;fswrapper.c']]],
  ['fs_5finit',['fs_init',['../group__fswrapper__api.html#ga2741666aeb80e863129b4ee1ac78a6a9',1,'fs_init(fs_mount_data *psMountPoints, uint32_t ui32NumMountPoints):&#160;fswrapper.c'],['../group__fswrapper__api.html#ga2741666aeb80e863129b4ee1ac78a6a9',1,'fs_init(fs_mount_data *psMountPoints, uint32_t ui32NumMountPoints):&#160;fswrapper.c']]],
  ['fs_5fmap_5fpath',['fs_map_path',['../group__fswrapper__api.html#ga879a29be2573e4ba57bfecb225dbd149',1,'fs_map_path(const char *pcPath, char *pcMapped, int iLen):&#160;fswrapper.c'],['../group__fswrapper__api.html#ga879a29be2573e4ba57bfecb225dbd149',1,'fs_map_path(const char *pcPath, char *pcMapped, int iLen):&#160;fswrapper.c']]],
  ['fs_5fmount_5fdata',['fs_mount_data',['../structfs__mount__data.html',1,'']]],
  ['fs_5fopen',['fs_open',['../group__fswrapper__api.html#gad16d92c5c4453acb1293162075f88561',1,'fs_open(const char *pcName):&#160;fswrapper.c'],['../group__fswrapper__api.html#gad16d92c5c4453acb1293162075f88561',1,'fs_open(const char *name):&#160;fswrapper.c']]],
  ['fs_5fread',['fs_read',['../group__fswrapper__api.html#ga89751b66ec3624430efad8987720c544',1,'fs_read(struct fs_file *phFile, char *pcBuffer, int iCount):&#160;fswrapper.c'],['../group__fswrapper__api.html#ga89751b66ec3624430efad8987720c544',1,'fs_read(struct fs_file *file, char *buffer, int count):&#160;fswrapper.c']]],
  ['fs_5ftick',['fs_tick',['../group__fswrapper__api.html#gacce076db140f0935e578601e387fd281',1,'fs_tick(uint32_t ui32TickMS):&#160;fswrapper.c'],['../group__fswrapper__api.html#gacce076db140f0935e578601e387fd281',1,'fs_tick(uint32_t ui32TickMS):&#160;fswrapper.c']]],
  ['fs_5fwrapper_5fdata',['fs_wrapper_data',['../structfs__wrapper__data.html',1,'']]],
  ['fswrapper_5fapi',['Fswrapper_api',['../group__fswrapper__api.html',1,'']]]
];
