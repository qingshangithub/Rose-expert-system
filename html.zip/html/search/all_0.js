var searchData=
[
  ['_5fttftpconnection',['_tTFTPConnection',['../struct__t_t_f_t_p_connection.html',1,'']]]
];
