var searchData=
[
  ['g_5fpscmdtable',['g_psCmdTable',['../group__cmdline__api.html#ga4905f9240abc3d1c19041aa7868306dc',1,'cmdline.h']]],
  ['g_5fpsschedulertable',['g_psSchedulerTable',['../group__scheduler__api.html#gadaed0be000cb8dc1266717a5e34bdf71',1,'scheduler.h']]],
  ['g_5fui32schedulernumtasks',['g_ui32SchedulerNumTasks',['../group__scheduler__api.html#ga721f1c866648e9fe8293537f28483edc',1,'scheduler.h']]]
];
