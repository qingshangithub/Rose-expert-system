var searchData=
[
  ['cmdlineprocess',['CmdLineProcess',['../group__cmdline__api.html#ga12a9baf85cb76825f7bfc20d79bd0b19',1,'CmdLineProcess(char *pcCmdLine):&#160;cmdline.c'],['../group__cmdline__api.html#ga12a9baf85cb76825f7bfc20d79bd0b19',1,'CmdLineProcess(char *pcCmdLine):&#160;cmdline.c']]],
  ['cpuusageinit',['CPUUsageInit',['../group__cpu__usage__api.html#ga4bb590c21fc503b6485534ac68168537',1,'CPUUsageInit(uint32_t ui32ClockRate, uint32_t ui32Rate, uint32_t ui32Timer):&#160;cpu_usage.c'],['../group__cpu__usage__api.html#ga4bb590c21fc503b6485534ac68168537',1,'CPUUsageInit(uint32_t ui32ClockRate, uint32_t ui32Rate, uint32_t ui32Timer):&#160;cpu_usage.c']]],
  ['cpuusagetick',['CPUUsageTick',['../group__cpu__usage__api.html#ga83379242f9580da9e4e71609494f2b48',1,'CPUUsageTick(void):&#160;cpu_usage.c'],['../group__cpu__usage__api.html#ga83379242f9580da9e4e71609494f2b48',1,'CPUUsageTick(void):&#160;cpu_usage.c']]]
];
