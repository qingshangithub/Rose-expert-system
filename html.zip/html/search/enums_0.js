var searchData=
[
  ['ttftperror',['tTFTPError',['../group__tftp__api.html#gac270d5df8beb3e25936e1818f3534c19',1,'tftp.h']]],
  ['ttftpmode',['tTFTPMode',['../group__tftp__api.html#ga5e59c278c012b3fd922db77f3996eacb',1,'tftp.h']]]
];
