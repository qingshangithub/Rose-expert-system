var searchData=
[
  ['cmdline_5fapi',['Cmdline_api',['../group__cmdline__api.html',1,'']]],
  ['cmdline_5fbad_5fcmd',['CMDLINE_BAD_CMD',['../group__cmdline__api.html#ga46f59766d93114ef1fc75d81c93e48f1',1,'cmdline.h']]],
  ['cmdline_5finvalid_5farg',['CMDLINE_INVALID_ARG',['../group__cmdline__api.html#ga358ce5f0f84f6a8b9e62ec0a3bfb042b',1,'cmdline.h']]],
  ['cmdline_5ftoo_5ffew_5fargs',['CMDLINE_TOO_FEW_ARGS',['../group__cmdline__api.html#ga7b1ec6329329925979066ddb6ffe618f',1,'cmdline.h']]],
  ['cmdline_5ftoo_5fmany_5fargs',['CMDLINE_TOO_MANY_ARGS',['../group__cmdline__api.html#ga53f41be1ab8c0de55c42629534e72933',1,'cmdline.h']]],
  ['cmdlineprocess',['CmdLineProcess',['../group__cmdline__api.html#ga12a9baf85cb76825f7bfc20d79bd0b19',1,'CmdLineProcess(char *pcCmdLine):&#160;cmdline.c'],['../group__cmdline__api.html#ga12a9baf85cb76825f7bfc20d79bd0b19',1,'CmdLineProcess(char *pcCmdLine):&#160;cmdline.c']]],
  ['cosine',['cosine',['../group__sine__api.html#gab8f2762adbd97f204e0a56b5a219156d',1,'sine.h']]],
  ['cpu_5fusage_5fapi',['Cpu_usage_api',['../group__cpu__usage__api.html',1,'']]],
  ['cpuusageinit',['CPUUsageInit',['../group__cpu__usage__api.html#ga4bb590c21fc503b6485534ac68168537',1,'CPUUsageInit(uint32_t ui32ClockRate, uint32_t ui32Rate, uint32_t ui32Timer):&#160;cpu_usage.c'],['../group__cpu__usage__api.html#ga4bb590c21fc503b6485534ac68168537',1,'CPUUsageInit(uint32_t ui32ClockRate, uint32_t ui32Rate, uint32_t ui32Timer):&#160;cpu_usage.c']]],
  ['cpuusagetick',['CPUUsageTick',['../group__cpu__usage__api.html#ga83379242f9580da9e4e71609494f2b48',1,'CPUUsageTick(void):&#160;cpu_usage.c'],['../group__cpu__usage__api.html#ga83379242f9580da9e4e71609494f2b48',1,'CPUUsageTick(void):&#160;cpu_usage.c']]]
];
