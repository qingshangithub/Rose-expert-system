var searchData=
[
  ['isqrt_5fapi',['Isqrt_api',['../group__isqrt__api.html',1,'']]]
];
