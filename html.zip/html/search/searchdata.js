var indexSectionsWithContent =
{
  0: "_bcefgilprstu",
  1: "_ft",
  2: "cefilrstu",
  3: "bgpu",
  4: "t",
  5: "t",
  6: "cefilrstu"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "variables",
  4: "typedefs",
  5: "enums",
  6: "groups"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Functions",
  3: "Variables",
  4: "Typedefs",
  5: "Enumerations",
  6: "Modules"
};

