var searchData=
[
  ['bactive',['bActive',['../structt_scheduler_task.html#afd377e303e95fa1e49530d56b09d3d98',1,'tSchedulerTask']]],
  ['busedma',['bUseDMA',['../structt_s_p_i_flash_state.html#a9d30f7e0f2f5d2f56c99e1be2c232511',1,'tSPIFlashState']]]
];
