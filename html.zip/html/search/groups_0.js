var searchData=
[
  ['cmdline_5fapi',['Cmdline_api',['../group__cmdline__api.html',1,'']]],
  ['cpu_5fusage_5fapi',['Cpu_usage_api',['../group__cpu__usage__api.html',1,'']]]
];
