var searchData=
[
  ['isqrt',['isqrt',['../group__isqrt__api.html#ga5ab7c23f31e80fb6742ebc62e5f58ba3',1,'isqrt(uint32_t ui32Value):&#160;isqrt.c'],['../group__isqrt__api.html#ga5ab7c23f31e80fb6742ebc62e5f58ba3',1,'isqrt(uint32_t ui32Value):&#160;isqrt.c']]],
  ['isqrt_5fapi',['Isqrt_api',['../group__isqrt__api.html',1,'']]]
];
